const mockIncidents = [
  {
    id: 1,
    title: "Biased Recommendation Algorithm",
    description: "Algorithm consistently favored certain demographics...",
    severity: "Medium",
    reported_at: "2025-03-15T10:00:00Z",
  },
  {
    id: 2,
    title: "LLM Hallucination in Critical Info",
    description: "LLM provided incorrect safety procedure information...",
    severity: "High",
    reported_at: "2025-04-01T14:30:00Z",
  },
  {
    id: 3,
    title: "Minor Data Leak via Chatbot",
    description: "Chatbot inadvertently exposed non-sensitive user metadata...",
    severity: "Low",
    reported_at: "2025-03-20T09:15:00Z",
  },
];

let incidents = [...mockIncidents];

const incidentListEl = document.getElementById("incidentList");
const severityFilterEl = document.getElementById("severityFilter");
const dateSortEl = document.getElementById("dateSort");
const reportForm = document.getElementById("reportForm");

function formatDate(dateStr) {
  const options = { year: "numeric", month: "short", day: "numeric" };
  return new Date(dateStr).toLocaleDateString(undefined, options);
}

function renderIncidents() {
  incidentListEl.innerHTML = "";

  let filtered = incidents;
  const severityFilter = severityFilterEl.value;
  if (severityFilter !== "All") {
    filtered = filtered.filter((inc) => inc.severity === severityFilter);
  }

  const sortOrder = dateSortEl.value;
  filtered.sort((a, b) => {
    if (sortOrder === "newest") {
      return new Date(b.reported_at) - new Date(a.reported_at);
    } else {
      return new Date(a.reported_at) - new Date(b.reported_at);
    }
  });

  filtered.forEach((incident) => {
    const item = document.createElement("div");
    item.className = "incident-item";

    const header = document.createElement("div");
    header.className = "incident-header";

    const title = document.createElement("div");
    title.className = "incident-title";
    title.textContent = incident.title;

    const severity = document.createElement("div");
    severity.className = `incident-severity severity-${incident.severity}`;
    severity.textContent = incident.severity;

    const date = document.createElement("div");
    date.className = "incident-date";
    date.textContent = formatDate(incident.reported_at);

    const viewDetailsBtn = document.createElement("button");
    viewDetailsBtn.className = "view-details-btn";
    viewDetailsBtn.textContent = "View Details";
    viewDetailsBtn.setAttribute("aria-expanded", "false");

    const description = document.createElement("div");
    description.className = "incident-description";
    description.textContent = incident.description;

    viewDetailsBtn.addEventListener("click", () => {
      const expanded = viewDetailsBtn.getAttribute("aria-expanded") === "true";
      viewDetailsBtn.setAttribute("aria-expanded", String(!expanded));
      if (!expanded) {
        description.style.display = "block";
        viewDetailsBtn.textContent = "Hide Details";
      } else {
        description.style.display = "none";
        viewDetailsBtn.textContent = "View Details";
      }
    });

    header.appendChild(title);
    header.appendChild(severity);
    header.appendChild(date);
    header.appendChild(viewDetailsBtn);

    item.appendChild(header);
    item.appendChild(description);

    incidentListEl.appendChild(item);
  });
}

severityFilterEl.addEventListener("change", renderIncidents);
dateSortEl.addEventListener("change", renderIncidents);

reportForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const title = reportForm.title.value.trim();
  const description = reportForm.description.value.trim();
  const severity = reportForm.severity.value;

  if (!title || !description || !severity) {
    alert("Please fill in all fields.");
    return;
  }

  const newIncident = {
    id: incidents.length ? incidents[incidents.length - 1].id + 1 : 1,
    title,
    description,
    severity,
    reported_at: new Date().toISOString(),
  };

  incidents.push(newIncident);
  renderIncidents();
  reportForm.reset();
});

renderIncidents();
